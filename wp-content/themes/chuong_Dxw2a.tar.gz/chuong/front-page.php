<?php
get_header();
?>
<!-- 特色区域 -->
<div id="featured - area">
    <img src="<?php echo get_template_directory_uri();?>/assets/images/featured.jpg" alt="Featured Image">
    <p>这是首页的特色介绍文字。</p>
</div>
<!-- 最新文章区域 -->
<div id="latest - posts">
    <h2>最新文章</h2>
    <?php
    $args = array(
        'post_type' => 'post',
        'posts_per_page' => 5 // 显示5篇最新文章
    );
    $latest_posts_query = new WP_Query($args);
    if ($latest_posts_query->have_posts()) {
        while ($latest_posts_query->have_posts()) {
            $latest_posts_query->the_post();?>
            <article>
                <h3><a href="<?php the_permalink();?>"><?php the_title();?></a></h3>
                <?php the_excerpt();?>
            </article>
        <?php }
        wp_reset_postdata();
    }
   ?>
</div>
<?php
get_footer();
?>


