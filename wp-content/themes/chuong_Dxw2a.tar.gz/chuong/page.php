<?php

echo 'page.php';

?>