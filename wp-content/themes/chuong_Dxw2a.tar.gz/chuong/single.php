<?php

echo 'single.php';

?>